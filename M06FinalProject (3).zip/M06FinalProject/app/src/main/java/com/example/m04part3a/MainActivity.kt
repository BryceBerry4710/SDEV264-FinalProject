package com.example.m04part3a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cornButton.setOnClickListener {
            val intent = Intent(this, CornActivity::class.java)
            startActivity(intent)
        }
        beansButton.setOnClickListener {
            val intent = Intent(this, BeansActivity::class.java)
            startActivity(intent)
        }
            button_help.setOnClickListener {
                val intent3 = Intent(this, HelpActivity::class.java)
                startActivity(intent3)
        }
        preferencesBtn.setOnClickListener{
            val intent = Intent(this, preferences:: class.java)
            startActivity(intent)
        }

    }
}

