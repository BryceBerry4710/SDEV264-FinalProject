package com.example.m04part3a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_beans.*
import kotlinx.android.synthetic.main.activity_main.*

class BeansActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beans)

        menuButton2.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        confirmBtn.setOnClickListener{
            val intent = Intent(this, thankyou:: class.java)
            startActivity(intent)
        }
        fun onCalculateButtonClicked2(view: View) {

            val name2 = name2.text
            val a2 = hybridA2.text
            val b2 = hybridB2.text
            val c2 = hybridC2.text

            calculateButton2.setOnClickListener {

                val sumResult2 =
                    (a2.toString().toDouble() * 27) + (b2.toString().toDouble() * 19) + (c2.toString()
                        .toDouble() * 32)
                finalPrice2.text ="$" + sumResult2.toString()
                nameFinal2.text = name2.toString()
            }
        }
    }
    fun onCalculateButtonClicked2(view: View) {
        val name = name2.text
        val a2 = hybridA2.text
        val b2 = hybridB2.text
        val c2 = hybridC2.text

        calculateButton2.setOnClickListener {

            val sumResult =
                (a2.toString().toDouble() * 12) + (b2.toString()
                    .toDouble() * 15) + (c2.toString()
                    .toDouble() * 9)
            finalPrice2.text = "$" + sumResult.toString()
            nameFinal2.text ="Name: " + name.toString()
        }
    }
}