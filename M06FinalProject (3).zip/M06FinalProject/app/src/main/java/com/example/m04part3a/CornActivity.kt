package com.example.m04part3a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_beans.*
import kotlinx.android.synthetic.main.activity_corn.*

class CornActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_corn)

        menuButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        confirmBtn2.setOnClickListener{
            val intent = Intent(this, thankyou:: class.java)
            startActivity(intent)
        }
        fun onCalculateButtonClicked(view: View) {

            val name = name.text
            val a = hybridA.text
            val b = hybridB.text
            val c = hybridC.text

            calculateButton.setOnClickListener {

                val sumResult =
                    (a.toString().toDouble() * 12) + (b.toString().toDouble() * 15) + (c.toString()
                        .toDouble() * 9)
                finalPrice.text ="$" + sumResult.toString()
                nameFinal.text = name.toString()
            }
        }
    }
                fun onCalculateButtonClicked(view: View) {
                    val name = name.text
                    val a = hybridA.text
                    val b = hybridB.text
                    val c = hybridC.text

                    calculateButton.setOnClickListener {

                        val sumResult =
                            (a.toString().toDouble() * 12) + (b.toString()
                                .toDouble() * 15) + (c.toString()
                                .toDouble() * 9)
                        finalPrice.text = "$" + sumResult.toString()
                        nameFinal.text ="Name: " + name.toString()
                    }
                }
            }